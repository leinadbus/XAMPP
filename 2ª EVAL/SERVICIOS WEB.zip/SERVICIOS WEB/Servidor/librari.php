<?php
class librari {
    public function sumar ($num1,$num2) {
        $resultado = $num1+$num2;
        return $resultado;
    }

    public function restar ($num1,$num2) {
        $resultado = $num1-$num2;
        return $resultado;
    }

    public function multiplicar ($num1,$num2) {
        $resultado = $num1*$num2;
        return $resultado;
    }

    public function dividir ($num1,$num2) {
        $resultado = $num1/$num2;
        return $resultado;
    }

}
?>