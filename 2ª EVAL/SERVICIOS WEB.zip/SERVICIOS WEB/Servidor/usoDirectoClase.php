<?php
require "librari.php";

$lib = new librari();

//$response = $lib->sumar(9,7);

$respuesta = array ('suma'=>$lib->sumar(9,7),
                    'resta'=>$lib->restar(9,7),
                    'multiplicación'=>$lib->multiplicar(9,7),
                    'división'=>$lib->dividir(9,7));

print_r($respuesta) ;

?>