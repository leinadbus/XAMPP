<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>ERROR</title>
    </head>
    <body>
        <br>
		<h1>No se te permite el registro en esta aplicación</h1>
    </body>
</html>
